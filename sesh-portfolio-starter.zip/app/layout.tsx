import "./globals.css";

export const metadata = {
  title: "Sesh Hari | Web Developer",
  description: "Professional Web Developer creating modern websites."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
