export default function Home() {
  return <div>Sesh Hari Portfolio</div>;
}
